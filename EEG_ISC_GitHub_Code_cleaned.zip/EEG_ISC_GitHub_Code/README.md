# EEG-ISC Naturalistic Threat Viewing Analysis Code

This repository contains MATLAB analysis scripts for the manuscript:

**Condition-Related Dynamics of EEG Inter-Subject Synchrony During Naturalistic Threat Viewing**

The code reproduces the EEG inter-subject correlation (EEG-ISC) analyses reported in the manuscript, including the primary condition-level ISC analysis, robustness checks, electrode-level exploratory analyses, and the additional median-split own-group versus other-group ISC analysis requested during peer review.

## Requirements

- MATLAB R2021a or later recommended
- EEGLAB
- Statistics and Machine Learning Toolbox
- Signal Processing Toolbox is recommended for some FFT/windowing utilities

## Data availability note

The EEG `.set` files and individual behavioral scores are not included in this repository. To run the scripts, place the data locally and update the `USER SETTINGS` section at the top of each `.m` file.

Expected EEG file naming format:

```text
segmented_001.set
segmented_002.set
segmented_003.set
...
```

Expected local data organization:

```text
<projectRoot>/
├─ data/
│  ├─ jingxi data/       # Rest condition
│  ├─ kongju data/       # Fear/high-arousal condition
│  ├─ zhongxing data/    # Neutral condition
│  └─ STAI_T_scores.csv  # Local behavioral file; not uploaded here
└─ results/
```

`STAI_T_scores.csv` should contain at least the following columns:

```text
Subject_ID,STAI_T
001,...
002,...
```

A blank template is provided in `data_templates/STAI_T_scores_template.csv`. Copy this template to your local data folder as `<projectRoot>/data/STAI_T_scores.csv` and fill in the STAI-T values locally.

## Script order

Run the scripts from the `code/` folder in the following order after updating paths.

1. `01_main_isc_condition_time_dynamics.m`  
   Primary EEG-ISC analysis across Rest, Fear, and Neutral conditions. This script extracts delta/theta/alpha/beta band-power time courses using a 5-s FFT window with 1-s step, applies within-subject z-standardization, computes leave-one-out ISC using a 30-s correlation window, and outputs condition-level, early-late, and slope-based ISC summaries.

2. `02_window_length_sensitivity.m`  
   Recomputes ISC using 15-s, 30-s, and 60-s correlation windows to evaluate whether the condition effects depend on the correlation-window length.

3. `03_matched_duration_control.m`  
   Recomputes ISC after truncating all three conditions to the first 120 s to evaluate whether condition effects are explained by unequal time-series lengths.

4. `04_electrode_level_isc_topoplots.m`  
   Uses the long electrode-level ISC output from Script 01 to generate electrode-level ISC topography tables and combined topoplots for condition values and contrasts.

5. `05_electrodewise_regression_completecase.m`  
   Runs exploratory electrode-wise ISC-STAI regressions using complete-case electrodes and applies BH-FDR correction within each Model × Band family.

6. `06_median_split_own_other_isc.m`  
   Reproduces the exploratory median-split own-group versus other-group ISC analysis added in response to the reviewer comment about reference-group dependence of ISC.

## Manuscript-code mapping

- Primary condition-related ISC: Script 01
- Time-dynamics analyses: Script 01
- Window-length sensitivity: Script 02
- Matched-duration control: Script 03
- Electrode-level topographies: Script 04
- Electrode-wise ISC-STAI regressions: Script 05
- Median-split own-group/other-group ISC: Script 06

## Notes for reuse

Before running each script, edit only the paths in the `USER SETTINGS` section, especially:

```matlab
projectRoot = 'E:\ISC project';
eeglabPath  = 'E:\MATLAB\eeglab2024.0';
```

The scripts are intended to document and reproduce the analyses reported in the manuscript. They may require minor path adjustments depending on local folder organization.
