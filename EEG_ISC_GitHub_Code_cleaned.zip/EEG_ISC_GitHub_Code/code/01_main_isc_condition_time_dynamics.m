%% 01_main_isc_condition_time_dynamics.m
% Main EEG-ISC analysis for naturalistic threat-viewing study.
%
% This script reproduces the primary condition-level ISC analysis and
% time-dynamics summaries described in the manuscript:
%   - Conditions: Rest, Fear, Neutral
%   - Bands: Delta, Theta, Alpha, Beta
%   - Band-power extraction: 5-s FFT window, 1-s step
%   - Within-subject z-standardization over time for each channel x band
%   - Leave-one-out ISC using a 30-s sliding correlation window, 1-s step
%   - Fisher r-to-z transform
%   - Whole-head average ISC
%   - Condition comparisons with Friedman and Wilcoxon-Holm tests
%   - Early-late and temporal-slope summaries for within-clip dynamics
%
% Requirements: MATLAB, EEGLAB, Statistics and Machine Learning Toolbox.
% Before running, update the paths in the USER SETTINGS section.

clear; clc;

%% ===================== USER SETTINGS =====================

% Change only these paths before running.
projectRoot = 'E:\ISC project';          % <-- change this to your project folder
eeglabPath  = 'E:\MATLAB\eeglab2024.0'; % <-- change this to your EEGLAB folder
if ~isempty(eeglabPath) && isfolder(eeglabPath)
    addpath(eeglabPath);
end
try
    eeglab nogui;
catch
    warning('EEGLAB could not be started automatically. Make sure EEGLAB is on MATLAB path.');
end

% Data folders. Files should be named segmented_001.set, segmented_002.set, etc.
dataRoot    = fullfile(projectRoot, 'data');
resultsRoot = fullfile(projectRoot, 'results');

condInfo = struct();
condInfo(1).Name = 'Rest';    condInfo(1).Dir = fullfile(dataRoot, 'jingxi data');
condInfo(2).Name = 'Fear';    condInfo(2).Dir = fullfile(dataRoot, 'kongju data');
condInfo(3).Name = 'Neutral'; condInfo(3).Dir = fullfile(dataRoot, 'zhongxing data');

outDir = fullfile(resultsRoot, 'main_isc_condition_time_dynamics');
if ~exist(outDir, 'dir'); mkdir(outDir); end

% Frequency bands included in the manuscript primary analyses.
bands = struct();
bands(1).Name = 'Delta'; bands(1).Range = [1 4];
bands(2).Name = 'Theta'; bands(2).Range = [4 8];
bands(3).Name = 'Alpha'; bands(3).Range = [8 13];
bands(4).Name = 'Beta';  bands(4).Range = [13 30];

% Band-power extraction parameters.
powerWinSec  = 5;
powerStepSec = 1;
useLogPower  = false;

% ISC window parameters for time-resolved ISC.
iscWinSec  = 30;
iscStepSec = 1;

%% ===================== DISCOVER FILES AND SUBJECTS =====================

fprintf('\n=== Discovering .set files ===\n');
for c = 1:numel(condInfo)
    files = dir(fullfile(condInfo(c).Dir, 'segmented_*.set'));
    if isempty(files)
        error('No segmented_*.set files found in: %s', condInfo(c).Dir);
    end

    subIDs = strings(numel(files), 1);
    fullPaths = strings(numel(files), 1);
    for i = 1:numel(files)
        subIDs(i) = parse_subject_id(files(i).name);
        fullPaths(i) = string(fullfile(files(i).folder, files(i).name));
    end

    [subIDs, order] = sort(subIDs);
    fullPaths = fullPaths(order);

    condInfo(c).SubIDs = subIDs;
    condInfo(c).Files = fullPaths;

    fprintf('%s: %d files\n', condInfo(c).Name, numel(files));
    disp(subIDs');
end

commonSubs = condInfo(1).SubIDs;
for c = 2:numel(condInfo)
    commonSubs = intersect(commonSubs, condInfo(c).SubIDs);
end
commonSubs = sort(commonSubs);

fprintf('\nCommon subjects across all conditions: %d\n', numel(commonSubs));
disp(commonSubs');
if numel(commonSubs) < 3
    error('Too few common subjects.');
end

%% ===================== FIND COMMON CHANNELS =====================

fprintf('\n=== Checking common channel labels ===\n');
allNormLabels = {};
firstLabels = strings(0,1);
firstNormLabels = strings(0,1);

for c = 1:numel(condInfo)
    for s = 1:numel(commonSubs)
        sid = commonSubs(s);
        filePath = condInfo(c).Files(condInfo(c).SubIDs == sid);
        EEG = pop_loadset(char(filePath), 'loadmode', 'info');
        labels = string({EEG.chanlocs.labels});
        normLabels = normalize_labels(labels);
        allNormLabels{end+1} = normLabels; %#ok<SAGROW>
        if isempty(firstLabels)
            firstLabels = labels;
            firstNormLabels = normLabels;
        end
    end
end

commonNormLabels = firstNormLabels;
for i = 1:numel(allNormLabels)
    commonNormLabels = commonNormLabels(ismember(commonNormLabels, allNormLabels{i}));
end
commonLabels = firstLabels(ismember(firstNormLabels, commonNormLabels));

fprintf('Common channels retained: %d\n', numel(commonLabels));
disp(commonLabels');
if numel(commonLabels) < 4
    error('Too few common channels.');
end

%% ===================== MAIN PROCESSING =====================

allRows = table();

for c = 1:numel(condInfo)
    condName = string(condInfo(c).Name);
    fprintf('\n=== Processing condition: %s ===\n', condName);

    nSub = numel(commonSubs);
    nChan = numel(commonLabels);
    nBand = numel(bands);

    powerCell = cell(nSub, 1);
    rawFileIDs = strings(nSub, 1);
    nTimeEach = zeros(nSub, 1);
    fsAll = zeros(nSub, 1);

    for s = 1:nSub
        sid = commonSubs(s);
        filePath = condInfo(c).Files(condInfo(c).SubIDs == sid);
        rawFileIDs(s) = filePath;

        fprintf('Loading %s | Subject %s\n', condName, sid);
        EEG = pop_loadset(char(filePath));
        fsAll(s) = EEG.srate;

        labels = string({EEG.chanlocs.labels});
        normLabels = normalize_labels(labels);
        chanIdx = zeros(nChan, 1);
        for ch = 1:nChan
            idx = find(normLabels == commonNormLabels(ch), 1);
            if isempty(idx)
                error('Channel %s not found in %s.', commonLabels(ch), filePath);
            end
            chanIdx(ch) = idx;
        end

        data = double(EEG.data(chanIdx, :));
        if ndims(data) == 3
            data = reshape(data, size(data,1), []);
        end

        bp = extract_band_power_sliding_fft(data, EEG.srate, bands, powerWinSec, powerStepSec, useLogPower);
        powerCell{s} = bp;  % time x channel x band
        nTimeEach(s) = size(bp, 1);
    end

    if numel(unique(fsAll)) > 1
        error('Sampling rates differ within condition %s.', condName);
    end

    minT = min(nTimeEach);
    fprintf('%s: power time points min=%d, max=%d. Using min=%d.\n', ...
        condName, min(nTimeEach), max(nTimeEach), minT);

    power4D = nan(nSub, minT, nChan, nBand);
    for s = 1:nSub
        power4D(s,:,:,:) = powerCell{s}(1:minT,:,:);
    end

    % Within-subject z-standardization: subject x condition x channel x band over time.
    power4D_z = nan(size(power4D));
    for s = 1:nSub
        for ch = 1:nChan
            for b = 1:nBand
                x = squeeze(power4D(s,:,ch,b));
                power4D_z(s,:,ch,b) = zscore_safe_row(x);
            end
        end
    end

    condRows = compute_time_resolved_isc(power4D_z, commonSubs, rawFileIDs, condName, ...
        commonLabels, bands, iscWinSec, iscStepSec, powerStepSec);

    allRows = [allRows; condRows]; %#ok<AGROW>
end

%% ===================== SAVE ELECTRODE-LEVEL LONG TABLE =====================

outLong = fullfile(outDir, 'ISC_results_long.csv');
writetable(allRows, outLong);
fprintf('\nSaved long ISC table:\n%s\n', outLong);

%% ===================== WHOLE-HEAD AVERAGE =====================

wholeRows = groupsummary(allRows, {'Subject_ID','Condition','Band'}, 'mean', ...
    {'ISC_meanZ','ISC_earlyZ','ISC_lateZ','ISC_slopeZ'});
wholeRows.Properties.VariableNames{'mean_ISC_meanZ'}  = 'ISC_meanZ';
wholeRows.Properties.VariableNames{'mean_ISC_earlyZ'} = 'ISC_earlyZ';
wholeRows.Properties.VariableNames{'mean_ISC_lateZ'}  = 'ISC_lateZ';
wholeRows.Properties.VariableNames{'mean_ISC_slopeZ'} = 'ISC_slopeZ';
wholeRows.GroupCount = [];
wholeRows.Channel = repmat("WholeHead", height(wholeRows), 1);

outWhole = fullfile(outDir, 'ISC_wholehead.csv');
writetable(wholeRows, outWhole);
fprintf('Saved whole-head ISC table:\n%s\n', outWhole);

summaryRows = groupsummary(wholeRows, {'Condition','Band'}, {'mean','std'}, 'ISC_meanZ');
summaryRows.Properties.VariableNames{'mean_ISC_meanZ'} = 'Mean_ISC_meanZ';
summaryRows.Properties.VariableNames{'std_ISC_meanZ'}  = 'SD_ISC_meanZ';
summaryRows.SEM_ISC_meanZ = summaryRows.SD_ISC_meanZ ./ sqrt(summaryRows.GroupCount);

outSummary = fullfile(outDir, 'ISC_condition_band_summary.csv');
writetable(summaryRows, outSummary);
fprintf('Saved condition-band summary:\n%s\n', outSummary);

%% ===================== CONDITION STATISTICS =====================

[statFriedman, statPosthoc] = run_condition_stats(wholeRows, bands);
writetable(statFriedman, fullfile(outDir, 'ISC_stats_friedman.csv'));
writetable(statPosthoc,  fullfile(outDir, 'ISC_stats_posthoc_Wilcoxon_Holm.csv'));

%% ===================== TIME-DYNAMICS STATISTICS =====================

[earlyLateStats, slopeStats, slopeContrastStats] = run_time_dynamics_stats(wholeRows, bands);
writetable(earlyLateStats,      fullfile(outDir, 'ISC_time_dynamics_early_late_stats.csv'));
writetable(slopeStats,          fullfile(outDir, 'ISC_time_dynamics_slope_one_sample_stats.csv'));
writetable(slopeContrastStats,  fullfile(outDir, 'ISC_time_dynamics_fear_neutral_slope_contrasts.csv'));

fprintf('\nAll done. Outputs saved to:\n%s\n', outDir);

%% ========================================================================
%% Local functions
%% ========================================================================

function sid = parse_subject_id(fname)
    tok = regexp(fname, 'segmented_(\d+)\.set', 'tokens', 'once');
    if isempty(tok); error('Cannot parse subject ID from file name: %s', fname); end
    sid = string(tok{1});
end

function normLabels = normalize_labels(labels)
    normLabels = upper(strtrim(string(labels)));
end

function bp = extract_band_power_sliding_fft(data, fs, bands, winSec, stepSec, useLogPower)
    [nChan, nSamp] = size(data);
    winSamp  = round(winSec * fs);
    stepSamp = round(stepSec * fs);
    if nSamp < winSamp; error('Data length is shorter than FFT window.'); end

    starts = 1:stepSamp:(nSamp - winSamp + 1);
    nWin = numel(starts);
    nBand = numel(bands);
    nfft = 2^nextpow2(winSamp);
    freq = (0:(nfft/2)) * fs / nfft;
    taper = hamming(winSamp)';
    bp = nan(nWin, nChan, nBand);

    for w = 1:nWin
        idx = starts(w):(starts(w) + winSamp - 1);
        seg = data(:, idx);
        seg = seg - mean(seg, 2, 'omitnan');
        seg = seg .* taper;
        X = fft(seg, nfft, 2);
        P = abs(X(:, 1:(nfft/2 + 1))).^2 ./ winSamp;

        for b = 1:nBand
            fidx = freq >= bands(b).Range(1) & freq < bands(b).Range(2);
            if ~any(fidx); error('No FFT bins found for band %s.', bands(b).Name); end
            val = mean(P(:, fidx), 2, 'omitnan');
            if useLogPower; val = log10(val + eps); end
            bp(w, :, b) = val;
        end
    end
end

function z = zscore_safe_row(x)
    x = x(:)';
    mu = mean(x, 'omitnan');
    sd = std(x, 0, 'omitnan');
    if isnan(sd) || sd == 0
        z = zeros(size(x));
        z(isnan(x)) = NaN;
    else
        z = (x - mu) ./ sd;
    end
end

function T = compute_time_resolved_isc(power4D_z, subIDs, rawFileIDs, condName, chanLabels, bands, iscWinSec, iscStepSec, powerStepSec)
    [nSub, nTime, nChan, nBand] = size(power4D_z);
    winPts  = round(iscWinSec  / powerStepSec);
    stepPts = round(iscStepSec / powerStepSec);
    if nTime < winPts; error('Power time series too short for ISC window.'); end
    starts = 1:stepPts:(nTime - winPts + 1);
    nCorrWin = numel(starts);

    rows = cell(nSub * nChan * nBand, 10);
    rr = 0;

    for b = 1:nBand
        for ch = 1:nChan
            X = squeeze(power4D_z(:,:,ch,b)); % subject x time
            for s = 1:nSub
                others = setdiff(1:nSub, s);
                ref = mean(X(others,:), 1, 'omitnan');
                zSeries = nan(nCorrWin, 1);
                for w = 1:nCorrWin
                    idx = starts(w):(starts(w) + winPts - 1);
                    r = corr(X(s,idx)', ref(idx)', 'Rows', 'complete');
                    zSeries(w) = fisher_z(r);
                end
                meanZ = mean(zSeries, 'omitnan');
                halfPoint = floor(nCorrWin / 2);
                earlyZ = mean(zSeries(1:halfPoint), 'omitnan');
                lateZ  = mean(zSeries((halfPoint+1):end), 'omitnan');
                t = ((1:nCorrWin)' - 1) * iscStepSec;
                ok = ~isnan(zSeries);
                if sum(ok) >= 3
                    p = polyfit(t(ok), zSeries(ok), 1);
                    slopeZ = p(1);
                else
                    slopeZ = NaN;
                end
                rr = rr + 1;
                rows(rr,:) = {subIDs(s), rawFileIDs(s), string(condName), string(bands(b).Name), ...
                    string(chanLabels(ch)), meanZ, earlyZ, lateZ, slopeZ, nCorrWin};
            end
        end
    end

    T = cell2table(rows, 'VariableNames', {'Subject_ID','RawFileID','Condition','Band','Channel', ...
        'ISC_meanZ','ISC_earlyZ','ISC_lateZ','ISC_slopeZ','nCorrWindows'});
end

function z = fisher_z(r)
    if isnan(r); z = NaN; return; end
    r = max(min(r, 0.999999), -0.999999);
    z = atanh(r);
end

function [friedT, posthocT] = run_condition_stats(wholeRows, bands)
    condOrder = ["Rest", "Fear", "Neutral"];
    friedRows = {};
    postRows = {};

    for b = 1:numel(bands)
        bandName = string(bands(b).Name);
        subList = unique(wholeRows.Subject_ID);
        X = nan(numel(subList), numel(condOrder));
        for s = 1:numel(subList)
            for c = 1:numel(condOrder)
                idx = wholeRows.Subject_ID == subList(s) & string(wholeRows.Condition) == condOrder(c) & string(wholeRows.Band) == bandName;
                if any(idx); X(s,c) = wholeRows.ISC_meanZ(find(idx,1)); end
            end
        end
        valid = all(~isnan(X), 2);
        Xv = X(valid,:);
        [pF, tbl] = friedman(Xv, 1, 'off');
        chi2 = tbl{2,5};
        friedRows(end+1,:) = {bandName, size(Xv,1), chi2, 2, pF}; %#ok<AGROW>

        pairs = [1 2; 1 3; 2 3];
        pairNames = ["Rest_vs_Fear", "Rest_vs_Neutral", "Fear_vs_Neutral"];
        pRaw = nan(3,1);
        zVal = nan(3,1);
        mean1 = nan(3,1); mean2 = nan(3,1); meanDiff = nan(3,1);
        for k = 1:3
            x1 = Xv(:, pairs(k,1));
            x2 = Xv(:, pairs(k,2));
            try
                [pRaw(k),~,stats] = signrank(x1, x2);
                if isfield(stats, 'zval'); zVal(k) = stats.zval; end
            catch
                pRaw(k) = NaN;
            end
            mean1(k) = mean(x1,'omitnan');
            mean2(k) = mean(x2,'omitnan');
            meanDiff(k) = mean(x2-x1,'omitnan');
        end
        pHolm = holm_adjust(pRaw);
        for k = 1:3
            postRows(end+1,:) = {bandName, pairNames(k), mean1(k), mean2(k), meanDiff(k), zVal(k), pRaw(k), pHolm(k)}; %#ok<AGROW>
        end
    end

    friedT = cell2table(friedRows, 'VariableNames', {'Band','N','ChiSquare','df','p_raw'});
    friedT.p_FDR_BH = bh_fdr(friedT.p_raw);
    posthocT = cell2table(postRows, 'VariableNames', {'Band','Contrast','Mean_Condition1','Mean_Condition2','MeanDiff_SecondMinusFirst','Z','p_raw','p_Holm'});
end

function [earlyLateStats, slopeStats, slopeContrastStats] = run_time_dynamics_stats(wholeRows, bands)
    condOrder = ["Rest", "Fear", "Neutral"];
    earlyRows = {};
    slopeRows = {};
    contrastRows = {};

    rr = 0;
    for c = 1:numel(condOrder)
        for b = 1:numel(bands)
            bandName = string(bands(b).Name);
            D = wholeRows(string(wholeRows.Condition)==condOrder(c) & string(wholeRows.Band)==bandName, :);
            diffEL = D.ISC_lateZ - D.ISC_earlyZ;
            [~,p,ci,stats] = ttest(D.ISC_lateZ, D.ISC_earlyZ);
            rr = rr + 1;
            earlyRows(rr,:) = {condOrder(c), bandName, height(D), mean(D.ISC_earlyZ,'omitnan'), mean(D.ISC_lateZ,'omitnan'), mean(diffEL,'omitnan'), stats.tstat, stats.df, p, ci(1), ci(2)}; %#ok<AGROW>

            [~,pS,ciS,statsS] = ttest(D.ISC_slopeZ, 0);
            slopeRows(rr,:) = {condOrder(c), bandName, height(D), mean(D.ISC_slopeZ,'omitnan'), statsS.tstat, statsS.df, pS, ciS(1), ciS(2)}; %#ok<AGROW>
        end
    end

    earlyLateStats = cell2table(earlyRows, 'VariableNames', {'Condition','Band','N','Mean_Early','Mean_Late','Mean_LateMinusEarly','t','df','p_raw','CI_low','CI_high'});
    earlyLateStats.p_FDR_BH = bh_fdr(earlyLateStats.p_raw);
    earlyLateStats.p_Holm = holm_adjust(earlyLateStats.p_raw);

    slopeStats = cell2table(slopeRows, 'VariableNames', {'Condition','Band','N','Mean_Slope','t','df','p_raw','CI_low','CI_high'});
    slopeStats.p_FDR_BH = bh_fdr(slopeStats.p_raw);
    slopeStats.p_Holm = holm_adjust(slopeStats.p_raw);

    for b = 1:numel(bands)
        bandName = string(bands(b).Name);
        subList = unique(wholeRows.Subject_ID);
        fear = nan(numel(subList),1); neutral = nan(numel(subList),1);
        for s = 1:numel(subList)
            idxF = wholeRows.Subject_ID==subList(s) & string(wholeRows.Condition)=="Fear" & string(wholeRows.Band)==bandName;
            idxN = wholeRows.Subject_ID==subList(s) & string(wholeRows.Condition)=="Neutral" & string(wholeRows.Band)==bandName;
            if any(idxF); fear(s) = wholeRows.ISC_slopeZ(find(idxF,1)); end
            if any(idxN); neutral(s) = wholeRows.ISC_slopeZ(find(idxN,1)); end
        end
        ok = isfinite(fear) & isfinite(neutral);
        [~,p,ci,stats] = ttest(fear(ok), neutral(ok));
        contrastRows(end+1,:) = {bandName, sum(ok), mean(fear(ok)-neutral(ok),'omitnan'), stats.tstat, stats.df, p, ci(1), ci(2)}; %#ok<AGROW>
    end
    slopeContrastStats = cell2table(contrastRows, 'VariableNames', {'Band','N','Mean_FearMinusNeutral_Slope','t','df','p_raw','CI_low','CI_high'});
    slopeContrastStats.p_FDR_BH = bh_fdr(slopeContrastStats.p_raw);
end

function pAdj = holm_adjust(p)
    pAdj = nan(size(p));
    valid = isfinite(p);
    pv = p(valid);
    [ps, order] = sort(pv);
    m = numel(ps);
    adj = nan(size(ps));
    for i = 1:m
        adj(i) = (m - i + 1) * ps(i);
    end
    for i = 2:m
        adj(i) = max(adj(i), adj(i-1));
    end
    adj = min(adj, 1);
    tmp = nan(size(pv)); tmp(order) = adj;
    pAdj(valid) = tmp;
end

function q = bh_fdr(p)
    p = p(:);
    q = nan(size(p));
    ok = isfinite(p);
    pv = p(ok);
    if isempty(pv); return; end
    [ps, order] = sort(pv);
    m = numel(ps);
    qs = ps .* m ./ (1:m)';
    qs = flipud(cummin(flipud(qs)));
    qs(qs > 1) = 1;
    tmp = nan(size(pv)); tmp(order) = qs;
    q(ok) = tmp;
end
