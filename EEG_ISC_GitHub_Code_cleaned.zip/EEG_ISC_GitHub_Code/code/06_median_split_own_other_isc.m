%% 06_median_split_own_other_isc.m
% Median-split own-group vs other-group ISC analysis.
%
% This script reproduces the exploratory analysis added in response to the
% reviewer comment about the reference-group dependence of ISC.
%
% Analysis steps:
%   1. Load fear-condition EEG .set files.
%   2. Extract Delta/Theta/Alpha/Beta band-power time courses.
%   3. Z-standardize each participant x channel x band time course.
%   4. Split participants into high- and low-anxiety subgroups by median STAI-T.
%   5. Compute subject-to-own-group and subject-to-other-group ISC.
%   6. Compare own-group and other-group broadband ISC with a paired t test.
%
% Requirements: MATLAB, EEGLAB, Statistics and Machine Learning Toolbox.
% Before running, update the paths in USER SETTINGS.

clear; clc;

%% ===================== USER SETTINGS =====================

projectRoot = 'E:\ISC project';          % <-- change this to your project folder
eeglabPath  = 'E:\MATLAB\eeglab2024.0'; % <-- change this to your EEGLAB folder
if ~isempty(eeglabPath) && isfolder(eeglabPath); addpath(eeglabPath); end
try; eeglab nogui; catch; warning('Could not start EEGLAB automatically.'); end

dataRoot    = fullfile(projectRoot, 'data');
resultsRoot = fullfile(projectRoot, 'results');

fearDir  = fullfile(dataRoot, 'kongju data');
staiFile = fullfile(projectRoot, 'data', 'STAI_T_scores.csv'); % local file; do not upload identifiable data
outDir   = fullfile(resultsRoot, 'median_split_own_other_ISC');
if ~exist(outDir, 'dir'); mkdir(outDir); end

% STAI CSV should contain columns:
%   Subject_ID, STAI_T
% Subject_ID should match EEG IDs, e.g., 001,002,003,004,005,006,008,...,018.

bands = struct();
bands(1).Name = 'Delta'; bands(1).Range = [1 4];
bands(2).Name = 'Theta'; bands(2).Range = [4 8];
bands(3).Name = 'Alpha'; bands(3).Range = [8 13];
bands(4).Name = 'Beta';  bands(4).Range = [13 30];

powerWinSec  = 5;
powerStepSec = 1;
useLogPower  = false;

%% ===================== DISCOVER FEAR FILES =====================

files = dir(fullfile(fearDir, 'segmented_*.set'));
if isempty(files)
    error('No segmented_*.set files found in: %s', fearDir);
end

subIDs = strings(numel(files),1);
setFiles = strings(numel(files),1);
segNums = nan(numel(files),1);
for i = 1:numel(files)
    subIDs(i) = parse_subject_id(files(i).name);
    segNums(i) = str2double(subIDs(i));
    setFiles(i) = string(fullfile(files(i).folder, files(i).name));
end
[subIDs, order] = sort(subIDs);
setFiles = setFiles(order);
segNums = segNums(order);

fprintf('\nSorted fear-condition EEG files:\n');
for i = 1:numel(setFiles)
    fprintf('Row %02d -> segmented_%s\n', i, subIDs(i));
end

%% ===================== READ STAI-T SCORES =====================

if ~isfile(staiFile)
    error('Cannot find STAI file: %s', staiFile);
end
S = readtable(staiFile, 'VariableNamingRule','preserve');
subjCol = find_column(S, ["Subject_ID","Subject","ID","subj","participant"]);
staiCol = find_column(S, ["STAI_T","STAIT","trait_anxiety","TraitAnxiety"]);

STAI = table();
STAI.Subject_ID = normalize_subject_id(S.(subjCol));
STAI.STAI_T = double(S.(staiCol));
STAI = STAI(isfinite(STAI.STAI_T) & strlength(STAI.Subject_ID)>0, :);

% Match STAI rows to EEG files by subject ID.
[hasSTAI, loc] = ismember(subIDs, STAI.Subject_ID);
if ~all(hasSTAI)
    fprintf('Missing STAI scores for these EEG subjects:\n');
    disp(subIDs(~hasSTAI)');
    error('Cannot continue without STAI-T scores for all EEG subjects.');
end
staiT = STAI.STAI_T(loc);

nSub = numel(subIDs);
if nSub < 4; error('Too few subjects for median-split analysis.'); end

%% ===================== MEDIAN SPLIT =====================

medianSTAI = median(staiT, 'omitnan');
isHigh = staiT > medianSTAI;
isLow  = staiT <= medianSTAI;

groupLabel = strings(nSub,1);
groupLabel(isHigh) = "High";
groupLabel(isLow) = "Low";

fprintf('\nMedian STAI-T = %.4f\n', medianSTAI);
fprintf('High anxiety group: n = %d\n', sum(isHigh));
fprintf('Low anxiety group : n = %d\n', sum(isLow));

if sum(isHigh) < 2 || sum(isLow) < 2
    error('One subgroup has fewer than 2 participants. Own-group ISC cannot be computed.');
end

%% ===================== LOAD EEG AND COMMON CHANNELS =====================

EEGs = cell(nSub,1);
labelsAll = cell(nSub,1);
fsAll = nan(nSub,1);

fprintf('\nLoading EEG files...\n');
for s = 1:nSub
    EEG = pop_loadset(char(setFiles(s)));
    data = double(EEG.data);
    if ndims(data)==3
        data = reshape(data, size(data,1), []);
        EEG.data = data;
        EEG.pnts = size(data,2);
        EEG.trials = 1;
    end
    EEGs{s} = EEG;
    fsAll(s) = EEG.srate;
    labelsAll{s} = normalize_labels(string({EEG.chanlocs.labels}));
    fprintf('Loaded %02d/%02d: segmented_%s | channels=%d | samples=%d | fs=%.1f Hz\n', ...
        s, nSub, subIDs(s), size(EEG.data,1), size(EEG.data,2), EEG.srate);
end

if numel(unique(fsAll)) > 1
    error('Sampling rates differ across files. Please resample first.');
end
fs = fsAll(1);

commonLabels = labelsAll{1};
for s = 2:nSub
    commonLabels = intersect_stable(commonLabels, labelsAll{s});
end
if isempty(commonLabels); error('No common channels found across subjects.'); end
fprintf('\nCommon channels used: %d\n', numel(commonLabels));

%% ===================== EXTRACT BAND-POWER TIME COURSES =====================

nBand = numel(bands);
bandPower = cell(nSub, nBand); % subject x band; each cell: channel x time_windows
nWinAll = nan(nSub,1);

fprintf('\nExtracting band-power time courses...\n');
for s = 1:nSub
    EEG = EEGs{s};
    labels = labelsAll{s};
    chanIdx = zeros(numel(commonLabels),1);
    for ch = 1:numel(commonLabels)
        idx = find(labels == commonLabels(ch), 1);
        if isempty(idx); error('Channel %s not found in subject %s.', commonLabels(ch), subIDs(s)); end
        chanIdx(ch) = idx;
    end
    data = double(EEG.data(chanIdx,:));
    tmp = compute_bandpower_timecourses(data, fs, bands, powerWinSec, powerStepSec, useLogPower);
    for b = 1:nBand
        X = tmp{b}; % channels x windows
        for ch = 1:size(X,1)
            X(ch,:) = zscore_safe_row(X(ch,:));
        end
        bandPower{s,b} = X;
    end
    nWinAll(s) = size(bandPower{s,1}, 2);
    fprintf('Subject %s | windows=%d\n', subIDs(s), nWinAll(s));
end

minNWin = min(nWinAll);
fprintf('\nMinimum time windows across subjects = %d\n', minNWin);
for s = 1:nSub
    for b = 1:nBand
        bandPower{s,b} = bandPower{s,b}(:, 1:minNWin);
    end
end

%% ===================== OWN-GROUP AND OTHER-GROUP ISC =====================

ownBandISC = nan(nSub,nBand);
otherBandISC = nan(nSub,nBand);

fprintf('\nComputing own-group and other-group ISC...\n');
for s = 1:nSub
    if isHigh(s)
        ownIdx = find(isHigh);
        otherIdx = find(isLow);
    else
        ownIdx = find(isLow);
        otherIdx = find(isHigh);
    end
    ownIdx(ownIdx == s) = []; % exclude target from own-group reference

    for b = 1:nBand
        target = bandPower{s,b};
        ownRef = average_reference_timecourse(bandPower, ownIdx, b);
        otherRef = average_reference_timecourse(bandPower, otherIdx, b);
        rOwn = nan(size(target,1),1);
        rOther = nan(size(target,1),1);
        for ch = 1:size(target,1)
            rOwn(ch) = safe_corr(target(ch,:), ownRef(ch,:));
            rOther(ch) = safe_corr(target(ch,:), otherRef(ch,:));
        end
        ownBandISC(s,b) = mean(fisher_z_vec(rOwn), 'omitnan');
        otherBandISC(s,b) = mean(fisher_z_vec(rOther), 'omitnan');
    end
end

ownBroadbandISC = mean(ownBandISC, 2, 'omitnan');
otherBroadbandISC = mean(otherBandISC, 2, 'omitnan');
diffISC = ownBroadbandISC - otherBroadbandISC;

%% ===================== STATISTICS =====================

Mown = mean(ownBroadbandISC, 'omitnan');
SDown = std(ownBroadbandISC, 0, 'omitnan');
Mother = mean(otherBroadbandISC, 'omitnan');
SDother = std(otherBroadbandISC, 0, 'omitnan');

[~, p_t, ci_t, stats_t] = ttest(ownBroadbandISC, otherBroadbandISC);
dz = mean(diffISC, 'omitnan') / std(diffISC, 0, 'omitnan');

fprintf('\n================ Main paired comparison ================\n');
fprintf('Own-group broadband ISC  : M = %.4f, SD = %.4f\n', Mown, SDown);
fprintf('Other-group broadband ISC: M = %.4f, SD = %.4f\n', Mother, SDother);
fprintf('Mean difference Own - Other = %.4f\n', mean(diffISC, 'omitnan'));
fprintf('Paired t-test: t(%d) = %.4f, p = %.4f, 95%% CI [%.4f, %.4f], Cohen dz = %.4f\n', ...
    stats_t.df, stats_t.tstat, p_t, ci_t(1), ci_t(2), dz);

try
    [p_w,~,stats_w] = signrank(ownBroadbandISC, otherBroadbandISC);
    wilcoxonSignedRank = stats_w.signedrank;
catch
    p_w = NaN;
    wilcoxonSignedRank = NaN;
end

%% ===================== SAVE OUTPUTS =====================

Tout = table();
Tout.Subject_ID = subIDs(:);
Tout.Segmented_ID = segNums(:);
Tout.Set_File = setFiles(:);
Tout.STAI_T = staiT(:);
Tout.Anxiety_Group = groupLabel(:);
for b = 1:nBand
    bn = string(bands(b).Name);
    Tout.("Own_" + bn) = ownBandISC(:,b);
    Tout.("Other_" + bn) = otherBandISC(:,b);
    Tout.("Diff_" + bn) = ownBandISC(:,b) - otherBandISC(:,b);
end
Tout.Own_Broadband_DeltaBeta = ownBroadbandISC;
Tout.Other_Broadband_DeltaBeta = otherBroadbandISC;
Tout.Diff_OwnMinusOther_Broadband = diffISC;

outSubject = fullfile(outDir, 'MedianSplit_OwnOther_ISC_subject_results.csv');
writetable(Tout, outSubject);

Tsum = table();
Tsum.Median_STAI_T = medianSTAI;
Tsum.N_High = sum(isHigh);
Tsum.N_Low = sum(isLow);
Tsum.M_Own = Mown;
Tsum.SD_Own = SDown;
Tsum.M_Other = Mother;
Tsum.SD_Other = SDother;
Tsum.M_Diff = mean(diffISC, 'omitnan');
Tsum.T_df = stats_t.df;
Tsum.T_value = stats_t.tstat;
Tsum.P_ttest = p_t;
Tsum.CI_low = ci_t(1);
Tsum.CI_high = ci_t(2);
Tsum.Cohen_dz = dz;
Tsum.Wilcoxon_signed_rank = wilcoxonSignedRank;
Tsum.P_wilcoxon = p_w;

outSummary = fullfile(outDir, 'MedianSplit_OwnOther_ISC_stat_summary.csv');
writetable(Tsum, outSummary);

fprintf('\nSaved subject-level results:\n%s\n', outSubject);
fprintf('Saved statistical summary:\n%s\n', outSummary);
fprintf('\nDone.\n');

%% ========================================================================
%% Local functions
%% ========================================================================

function sid = parse_subject_id(fname)
    tok = regexp(fname, 'segmented_(\d+)\.set', 'tokens', 'once');
    if isempty(tok); error('Cannot parse subject ID from file name: %s', fname); end
    sid = string(tok{1});
end

function col = find_column(T, candidates)
    vars = string(T.Properties.VariableNames);
    cleanVars = lower(regexprep(vars, '[^A-Za-z0-9]', ''));
    col = '';
    for c = candidates
        cc = lower(regexprep(string(c), '[^A-Za-z0-9]', ''));
        idx = find(cleanVars == cc, 1);
        if ~isempty(idx); col = char(vars(idx)); return; end
    end
    error('Could not find any of these columns: %s', strjoin(candidates, ', '));
end

function sid = normalize_subject_id(x)
    x = string(x); sid = strings(size(x));
    for i=1:numel(x)
        tok = regexp(char(x(i)), '\d+', 'match', 'once');
        if isempty(tok); sid(i)=strtrim(x(i)); else; sid(i)=string(sprintf('%03d', str2double(tok))); end
    end
end

function labels = normalize_labels(labels)
    labels = upper(strtrim(string(labels)));
    labels = regexprep(labels, '\s+', '');
    labels = regexprep(labels, '[\.\-_]', '');
    labels(labels=="T3")="T7"; labels(labels=="T4")="T8"; labels(labels=="T5")="P7"; labels(labels=="T6")="P8";
end

function common = intersect_stable(a, b)
    common = strings(0,1);
    for i = 1:numel(a)
        if any(a(i) == b)
            common(end+1,1) = a(i); %#ok<AGROW>
        end
    end
end

function bandPower = compute_bandpower_timecourses(data, fs, bands, winSec, stepSec, useLogPower)
    nChan = size(data,1); nSamp = size(data,2); nBand = numel(bands);
    winPts = round(winSec*fs); stepPts = round(stepSec*fs);
    if nSamp < winPts; error('Data length shorter than FFT window.'); end
    starts = 1:stepPts:(nSamp-winPts+1);
    nFFT = 2^nextpow2(winPts);
    freqs = fs*(0:(nFFT/2))/nFFT;
    taper = hamming(winPts)';
    bandPower = cell(nBand,1);
    for b=1:nBand; bandPower{b} = nan(nChan, numel(starts)); end
    for w=1:numel(starts)
        idx = starts(w):(starts(w)+winPts-1);
        seg = data(:,idx);
        seg = seg - mean(seg,2,'omitnan');
        seg = seg .* taper;
        Y = fft(seg,nFFT,2);
        P = abs(Y(:,1:(nFFT/2+1))).^2;
        for b=1:nBand
            fMask = freqs >= bands(b).Range(1) & freqs < bands(b).Range(2);
            bp = mean(P(:,fMask),2,'omitnan');
            if useLogPower; bp = log10(bp + eps); end
            bandPower{b}(:,w) = bp;
        end
    end
end

function z = zscore_safe_row(x)
    x = x(:)'; mu=mean(x,'omitnan'); sd=std(x,0,'omitnan');
    if isnan(sd)||sd==0; z=zeros(size(x)); z(isnan(x))=NaN; else; z=(x-mu)./sd; end
end

function ref = average_reference_timecourse(bandPower, idx, bandIndex)
    X = [];
    for k=1:numel(idx)
        X(:,:,k) = bandPower{idx(k), bandIndex}; %#ok<AGROW>
    end
    ref = mean(X, 3, 'omitnan');
end

function r = safe_corr(x,y)
    x=x(:); y=y(:); ok=isfinite(x)&isfinite(y); x=x(ok); y=y(ok);
    if numel(x)<3 || std(x)==0 || std(y)==0; r=NaN; return; end
    C=corrcoef(x,y); r=C(1,2);
end

function z = fisher_z_vec(r)
    r(r>=0.999999)=0.999999; r(r<=-0.999999)=-0.999999; z=atanh(r);
end
