%% 03_matched_duration_control.m
% Matched-duration control analysis.
%
% This script truncates Rest, Fear, and Neutral data to the same duration
% and recomputes whole-head leave-one-out ISC.
%
% Parameters are aligned with the main analysis:
%   - first 120 s of each condition
%   - 5-s FFT window, 1-s step
%   - Delta, Theta, Alpha, Beta
%   - within-subject z-standardization over time
%   - Fisher z-transformed leave-one-out ISC
%
% Requirements: MATLAB, EEGLAB, Statistics and Machine Learning Toolbox.

clear; clc;

%% ===================== USER SETTINGS =====================

projectRoot = 'E:\ISC project';          % <-- change this to your project folder
eeglabPath  = 'E:\MATLAB\eeglab2024.0'; % <-- change this to your EEGLAB folder
if ~isempty(eeglabPath) && isfolder(eeglabPath); addpath(eeglabPath); end
try; eeglab nogui; catch; warning('Could not start EEGLAB automatically.'); end

dataRoot    = fullfile(projectRoot, 'data');
resultsRoot = fullfile(projectRoot, 'results');

condInfo = struct();
condInfo(1).Name = 'Rest';    condInfo(1).Dir = fullfile(dataRoot, 'jingxi data');
condInfo(2).Name = 'Fear';    condInfo(2).Dir = fullfile(dataRoot, 'kongju data');
condInfo(3).Name = 'Neutral'; condInfo(3).Dir = fullfile(dataRoot, 'zhongxing data');

outDir = fullfile(resultsRoot, 'matched_duration_control');
if ~exist(outDir, 'dir'); mkdir(outDir); end

matchedDurationSec = 120;
powerWinSec = 5;
powerStepSec = 1;
useLogPower = false;

bands = struct();
bands(1).Name = 'Delta'; bands(1).Range = [1 4];
bands(2).Name = 'Theta'; bands(2).Range = [4 8];
bands(3).Name = 'Alpha'; bands(3).Range = [8 13];
bands(4).Name = 'Beta';  bands(4).Range = [13 30];

%% ===================== DISCOVER SUBJECTS AND CHANNELS =====================

[commonSubs, commonLabels, commonNormLabels, condInfo] = discover_common_subjects_channels(condInfo);
nSub = numel(commonSubs); nCond = numel(condInfo); nBand = numel(bands); nChan = numel(commonLabels);

%% ===================== COMPUTE ISC =====================

iscChan = nan(nSub, nCond, nBand, nChan);

for c = 1:nCond
    condName = string(condInfo(c).Name);
    fprintf('\nProcessing matched-duration data: %s\n', condName);
    powerCell = cell(nSub,1);
    fsAll = zeros(nSub,1);
    nWinAll = zeros(nSub,1);

    for s = 1:nSub
        sid = commonSubs(s);
        fp = condInfo(c).Files(condInfo(c).SubIDs == sid);
        EEG = pop_loadset(char(fp));
        fsAll(s) = EEG.srate;
        requiredSamples = round(matchedDurationSec * EEG.srate);
        if size(EEG.data,2) < requiredSamples
            error('Subject %s, condition %s is shorter than %d s.', sid, condName, matchedDurationSec);
        end
        labels = normalize_labels(string({EEG.chanlocs.labels}));
        chanIdx = zeros(nChan,1);
        for ch = 1:nChan
            idx = find(labels == commonNormLabels(ch), 1);
            if isempty(idx); error('Missing channel %s in %s', commonLabels(ch), fp); end
            chanIdx(ch) = idx;
        end
        data = double(EEG.data(chanIdx, 1:requiredSamples));
        bp = extract_band_power_sliding_fft(data, EEG.srate, bands, powerWinSec, powerStepSec, useLogPower);
        for ch = 1:nChan
            for b = 1:nBand
                bp(:,ch,b) = zscore_safe_col(bp(:,ch,b));
            end
        end
        powerCell{s} = bp; % time x channel x band
        nWinAll(s) = size(bp,1);
    end
    if numel(unique(fsAll)) > 1; error('Sampling rates differ in condition %s.', condName); end
    minWin = min(nWinAll);

    for b = 1:nBand
        for ch = 1:nChan
            X = nan(nSub, minWin);
            for s = 1:nSub
                tmp = powerCell{s};
                X(s,:) = squeeze(tmp(1:minWin,ch,b));
            end
            for s = 1:nSub
                ref = mean(X(setdiff(1:nSub,s),:),1,'omitnan');
                r = corr(X(s,:)', ref(:), 'Rows','complete');
                iscChan(s,c,b,ch) = fisher_z(r);
            end
        end
    end
end

iscWhole = squeeze(mean(iscChan, 4, 'omitnan')); % subject x condition x band

%% ===================== SAVE SUBJECT-LEVEL TABLE =====================

rows = cell(nSub*nCond*nBand,4); rr=0;
for s=1:nSub
    for c=1:nCond
        for b=1:nBand
            rr=rr+1;
            rows(rr,:) = {commonSubs(s), string(condInfo(c).Name), string(bands(b).Name), iscWhole(s,c,b)};
        end
    end
end
T_long = cell2table(rows, 'VariableNames', {'Subject_ID','Condition','Band','ISC_z'});
writetable(T_long, fullfile(outDir, 'matched_duration_ISC_subject_level_long.csv'));

T_desc = groupsummary(T_long, {'Condition','Band'}, {'mean','std'}, 'ISC_z');
T_desc.Properties.VariableNames{'mean_ISC_z'} = 'Mean_ISC_z';
T_desc.Properties.VariableNames{'std_ISC_z'} = 'SD_ISC_z';
T_desc.SEM_ISC_z = T_desc.SD_ISC_z ./ sqrt(T_desc.GroupCount);
writetable(T_desc, fullfile(outDir, 'matched_duration_descriptives.csv'));

[T_friedman, T_posthoc] = run_condition_stats(T_long, bands);
writetable(T_friedman, fullfile(outDir, 'matched_duration_Friedman_by_band.csv'));
writetable(T_posthoc,  fullfile(outDir, 'matched_duration_posthoc_Wilcoxon_Holm.csv'));

save(fullfile(outDir, 'matched_duration_ISC_all_results.mat'), 'iscWhole','iscChan','commonSubs','condInfo','bands','commonLabels','matchedDurationSec','T_long','T_desc','T_friedman','T_posthoc');

fprintf('\nAll done. Outputs saved to:\n%s\n', outDir);

%% ========================================================================
%% Local functions
%% ========================================================================

function [commonSubs, commonLabels, commonNormLabels, condInfo] = discover_common_subjects_channels(condInfo)
    for c=1:numel(condInfo)
        files=dir(fullfile(condInfo(c).Dir,'segmented_*.set'));
        if isempty(files); error('No files found in %s', condInfo(c).Dir); end
        subIDs=strings(numel(files),1); paths=strings(numel(files),1);
        for i=1:numel(files)
            subIDs(i)=parse_subject_id(files(i).name);
            paths(i)=string(fullfile(files(i).folder,files(i).name));
        end
        [subIDs,order]=sort(subIDs); paths=paths(order);
        condInfo(c).SubIDs=subIDs; condInfo(c).Files=paths;
    end
    commonSubs=condInfo(1).SubIDs;
    for c=2:numel(condInfo); commonSubs=intersect(commonSubs,condInfo(c).SubIDs); end
    commonSubs=sort(commonSubs);
    allNorm={}; firstLabels=strings(0,1); firstNorm=strings(0,1);
    for c=1:numel(condInfo)
        for s=1:numel(commonSubs)
            fp=condInfo(c).Files(condInfo(c).SubIDs==commonSubs(s));
            EEG=pop_loadset(char(fp),'loadmode','info');
            labels=string({EEG.chanlocs.labels}); norm=normalize_labels(labels);
            allNorm{end+1}=norm; %#ok<AGROW>
            if isempty(firstLabels); firstLabels=labels; firstNorm=norm; end
        end
    end
    commonNormLabels=firstNorm;
    for i=1:numel(allNorm); commonNormLabels=commonNormLabels(ismember(commonNormLabels,allNorm{i})); end
    commonLabels=firstLabels(ismember(firstNorm,commonNormLabels));
    fprintf('Common subjects: %d; common channels: %d\n', numel(commonSubs), numel(commonLabels));
end

function sid=parse_subject_id(fname)
    tok=regexp(fname,'segmented_(\d+)\.set','tokens','once');
    if isempty(tok); error('Cannot parse subject ID: %s', fname); end
    sid=string(tok{1});
end
function normLabels=normalize_labels(labels); normLabels=upper(strtrim(string(labels))); end

function bp=extract_band_power_sliding_fft(data,fs,bands,winSec,stepSec,useLogPower)
    [nChan,nSamp]=size(data); winSamp=round(winSec*fs); stepSamp=round(stepSec*fs);
    starts=1:stepSamp:(nSamp-winSamp+1); nWin=numel(starts); nBand=numel(bands);
    nfft=2^nextpow2(winSamp); freq=(0:(nfft/2))*fs/nfft; taper=hamming(winSamp)';
    bp=nan(nWin,nChan,nBand);
    for w=1:nWin
        idx=starts(w):(starts(w)+winSamp-1); seg=data(:,idx); seg=seg-mean(seg,2,'omitnan'); seg=seg.*taper;
        X=fft(seg,nfft,2); P=abs(X(:,1:(nfft/2+1))).^2 ./ winSamp;
        for b=1:nBand
            fidx=freq>=bands(b).Range(1) & freq<bands(b).Range(2);
            val=mean(P(:,fidx),2,'omitnan'); if useLogPower; val=log10(val+eps); end
            bp(w,:,b)=val;
        end
    end
end

function z=zscore_safe_col(x)
    mu=mean(x,'omitnan'); sd=std(x,0,'omitnan');
    if isnan(sd)||sd==0; z=zeros(size(x)); z(isnan(x))=NaN; else; z=(x-mu)./sd; end
end

function z=fisher_z(r)
    if isnan(r); z=NaN; return; end
    r=max(min(r,0.999999),-0.999999); z=atanh(r);
end

function [friedT,posthocT]=run_condition_stats(T,bands)
    condOrder=["Rest","Fear","Neutral"]; friedRows={}; postRows={};
    for b=1:numel(bands)
        bandName=string(bands(b).Name); subList=unique(T.Subject_ID); X=nan(numel(subList),3);
        for s=1:numel(subList)
            for c=1:3
                idx=T.Subject_ID==subList(s) & string(T.Condition)==condOrder(c) & string(T.Band)==bandName;
                if any(idx); X(s,c)=T.ISC_z(find(idx,1)); end
            end
        end
        Xv=X(all(isfinite(X),2),:); [pF,tbl]=friedman(Xv,1,'off');
        friedRows(end+1,:)={bandName,size(Xv,1),tbl{2,5},tbl{2,3},pF}; %#ok<AGROW>
        pairs=[1 2;1 3;2 3]; pairNames=["Rest_vs_Fear","Rest_vs_Neutral","Fear_vs_Neutral"];
        pRaw=nan(3,1); zVal=nan(3,1); md=nan(3,1); m1=nan(3,1); m2=nan(3,1);
        for k=1:3
            x1=Xv(:,pairs(k,1)); x2=Xv(:,pairs(k,2));
            try; [pRaw(k),~,stats]=signrank(x1,x2); if isfield(stats,'zval'); zVal(k)=stats.zval; end; catch; pRaw(k)=NaN; end
            m1(k)=mean(x1,'omitnan'); m2(k)=mean(x2,'omitnan'); md(k)=mean(x2-x1,'omitnan');
        end
        pHolm=holm_adjust(pRaw);
        for k=1:3; postRows(end+1,:)={bandName,pairNames(k),m1(k),m2(k),md(k),zVal(k),pRaw(k),pHolm(k)}; end %#ok<AGROW>
    end
    friedT=cell2table(friedRows,'VariableNames',{'Band','N','ChiSquare','df','p_raw'}); friedT.p_FDR_BH=bh_fdr(friedT.p_raw);
    posthocT=cell2table(postRows,'VariableNames',{'Band','Contrast','Mean_Condition1','Mean_Condition2','MeanDiff_SecondMinusFirst','Z','p_raw','p_Holm'});
end
function pAdj=holm_adjust(p); pAdj=nan(size(p)); ok=isfinite(p); pv=p(ok); [ps,order]=sort(pv); m=numel(ps); adj=nan(size(ps)); for i=1:m; adj(i)=(m-i+1)*ps(i); end; for i=2:m; adj(i)=max(adj(i),adj(i-1)); end; adj=min(adj,1); tmp=nan(size(pv)); tmp(order)=adj; pAdj(ok)=tmp; end
function q=bh_fdr(p); p=p(:); q=nan(size(p)); ok=isfinite(p); pv=p(ok); if isempty(pv); return; end; [ps,order]=sort(pv); m=numel(ps); qs=ps.*m./(1:m)'; qs=flipud(cummin(flipud(qs))); qs(qs>1)=1; tmp=nan(size(pv)); tmp(order)=qs; q(ok)=tmp; end
