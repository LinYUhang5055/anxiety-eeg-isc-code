%% 02_window_length_sensitivity.m
% Window-length sensitivity analysis for EEG-ISC.
%
% This script recomputes condition-level ISC using 15-s, 30-s, and 60-s
% correlation windows on z-standardized band-power time courses.
% It tests condition differences within each WindowLength x Band cell.
%
% Requirements: MATLAB, EEGLAB, Statistics and Machine Learning Toolbox.
% Before running, update the paths in USER SETTINGS.

clear; clc;

%% ===================== USER SETTINGS =====================

projectRoot = 'E:\ISC project';          % <-- change this to your project folder
eeglabPath  = 'E:\MATLAB\eeglab2024.0'; % <-- change this to your EEGLAB folder
if ~isempty(eeglabPath) && isfolder(eeglabPath); addpath(eeglabPath); end
try; eeglab nogui; catch; warning('Could not start EEGLAB automatically.'); end

dataRoot    = fullfile(projectRoot, 'data');
resultsRoot = fullfile(projectRoot, 'results');

condInfo = struct();
condInfo(1).Name = 'Rest';    condInfo(1).Dir = fullfile(dataRoot, 'jingxi data');
condInfo(2).Name = 'Fear';    condInfo(2).Dir = fullfile(dataRoot, 'kongju data');
condInfo(3).Name = 'Neutral'; condInfo(3).Dir = fullfile(dataRoot, 'zhongxing data');

outDir = fullfile(resultsRoot, 'window_length_sensitivity');
if ~exist(outDir, 'dir'); mkdir(outDir); end

bands = struct();
bands(1).Name = 'Delta'; bands(1).Range = [1 4];
bands(2).Name = 'Theta'; bands(2).Range = [4 8];
bands(3).Name = 'Alpha'; bands(3).Range = [8 13];
bands(4).Name = 'Beta';  bands(4).Range = [13 30];

powerWinSec  = 5;
powerStepSec = 1;
useLogPower  = false;
iscWinListSec = [15 30 60];
iscStepSec = 1;

%% ===================== LOAD AND PREPARE BAND POWER ONCE =====================

[commonSubs, commonLabels, commonNormLabels, condInfo] = discover_common_subjects_channels(condInfo);
[nSub, nCond, nBand, nChan] = deal(numel(commonSubs), numel(condInfo), numel(bands), numel(commonLabels));

powerByCond = cell(nCond, 1); % each: subject x time x channel x band
for c = 1:nCond
    condName = string(condInfo(c).Name);
    fprintf('\nExtracting band-power time courses for %s...\n', condName);
    powerCell = cell(nSub,1);
    nTimeEach = zeros(nSub,1);
    fsAll = zeros(nSub,1);

    for s = 1:nSub
        sid = commonSubs(s);
        filePath = condInfo(c).Files(condInfo(c).SubIDs == sid);
        EEG = pop_loadset(char(filePath));
        fsAll(s) = EEG.srate;
        labels = normalize_labels(string({EEG.chanlocs.labels}));
        chanIdx = zeros(nChan,1);
        for ch = 1:nChan
            idx = find(labels == commonNormLabels(ch), 1);
            if isempty(idx); error('Missing channel %s in %s', commonLabels(ch), filePath); end
            chanIdx(ch) = idx;
        end
        data = double(EEG.data(chanIdx,:));
        if ndims(data)==3; data = reshape(data, size(data,1), []); end
        bp = extract_band_power_sliding_fft(data, EEG.srate, bands, powerWinSec, powerStepSec, useLogPower);
        powerCell{s} = bp;
        nTimeEach(s) = size(bp,1);
    end
    if numel(unique(fsAll)) > 1; error('Sampling rates differ in %s.', condName); end
    minT = min(nTimeEach);
    P = nan(nSub, minT, nChan, nBand);
    for s = 1:nSub
        P(s,:,:,:) = powerCell{s}(1:minT,:,:);
    end
    % z-standardize within subject x condition x channel x band.
    Pz = nan(size(P));
    for s = 1:nSub
        for ch = 1:nChan
            for b = 1:nBand
                Pz(s,:,ch,b) = zscore_safe_row(squeeze(P(s,:,ch,b)));
            end
        end
    end
    powerByCond{c} = Pz;
end

%% ===================== WINDOW-LENGTH LOOP =====================

allRows = table();

for wi = 1:numel(iscWinListSec)
    winSec = iscWinListSec(wi);
    fprintf('\n=== Computing ISC for correlation window = %d s ===\n', winSec);

    for c = 1:nCond
        rows = compute_windowed_isc_mean(powerByCond{c}, commonSubs, string(condInfo(c).Name), bands, winSec, iscStepSec, powerStepSec);
        rows.WinSec = repmat(winSec, height(rows), 1);
        allRows = [allRows; rows]; %#ok<AGROW>
    end
end

outSubject = fullfile(outDir, 'window_length_sensitivity_subject_level.csv');
writetable(allRows, outSubject);

summaryRows = groupsummary(allRows, {'WinSec','Condition','Band'}, {'mean','std'}, 'ISC_meanZ');
summaryRows.Properties.VariableNames{'mean_ISC_meanZ'} = 'Mean_ISC_meanZ';
summaryRows.Properties.VariableNames{'std_ISC_meanZ'}  = 'SD_ISC_meanZ';
summaryRows.SEM_ISC_meanZ = summaryRows.SD_ISC_meanZ ./ sqrt(summaryRows.GroupCount);
writetable(summaryRows, fullfile(outDir, 'window_length_sensitivity_summary.csv'));

[statFriedman, statPosthoc] = run_window_condition_stats(allRows, bands, iscWinListSec);
writetable(statFriedman, fullfile(outDir, 'window_length_sensitivity_Friedman.csv'));
writetable(statPosthoc,  fullfile(outDir, 'window_length_sensitivity_posthoc_Wilcoxon_Holm.csv'));

fprintf('\nAll done. Outputs saved to:\n%s\n', outDir);

%% ========================================================================
%% Local functions
%% ========================================================================

function [commonSubs, commonLabels, commonNormLabels, condInfo] = discover_common_subjects_channels(condInfo)
    for c = 1:numel(condInfo)
        files = dir(fullfile(condInfo(c).Dir, 'segmented_*.set'));
        if isempty(files); error('No files found in %s', condInfo(c).Dir); end
        subIDs = strings(numel(files),1); paths = strings(numel(files),1);
        for i = 1:numel(files)
            subIDs(i) = parse_subject_id(files(i).name);
            paths(i) = string(fullfile(files(i).folder, files(i).name));
        end
        [subIDs, order] = sort(subIDs); paths = paths(order);
        condInfo(c).SubIDs = subIDs; condInfo(c).Files = paths;
    end
    commonSubs = condInfo(1).SubIDs;
    for c = 2:numel(condInfo); commonSubs = intersect(commonSubs, condInfo(c).SubIDs); end
    commonSubs = sort(commonSubs);
    allNorm = {}; firstLabels = strings(0,1); firstNorm = strings(0,1);
    for c = 1:numel(condInfo)
        for s = 1:numel(commonSubs)
            sid = commonSubs(s);
            fp = condInfo(c).Files(condInfo(c).SubIDs == sid);
            EEG = pop_loadset(char(fp), 'loadmode', 'info');
            labels = string({EEG.chanlocs.labels});
            norm = normalize_labels(labels);
            allNorm{end+1} = norm; %#ok<AGROW>
            if isempty(firstLabels); firstLabels = labels; firstNorm = norm; end
        end
    end
    commonNormLabels = firstNorm;
    for i = 1:numel(allNorm); commonNormLabels = commonNormLabels(ismember(commonNormLabels, allNorm{i})); end
    commonLabels = firstLabels(ismember(firstNorm, commonNormLabels));
    fprintf('Common subjects: %d; common channels: %d\n', numel(commonSubs), numel(commonLabels));
end

function sid = parse_subject_id(fname)
    tok = regexp(fname, 'segmented_(\d+)\.set', 'tokens', 'once');
    if isempty(tok); error('Cannot parse subject ID: %s', fname); end
    sid = string(tok{1});
end

function normLabels = normalize_labels(labels)
    normLabels = upper(strtrim(string(labels)));
end

function bp = extract_band_power_sliding_fft(data, fs, bands, winSec, stepSec, useLogPower)
    [nChan, nSamp] = size(data);
    winSamp = round(winSec*fs); stepSamp = round(stepSec*fs);
    starts = 1:stepSamp:(nSamp-winSamp+1);
    nWin = numel(starts); nBand = numel(bands);
    nfft = 2^nextpow2(winSamp);
    freq = (0:(nfft/2))*fs/nfft;
    taper = hamming(winSamp)';
    bp = nan(nWin, nChan, nBand);
    for w = 1:nWin
        idx = starts(w):(starts(w)+winSamp-1);
        seg = data(:,idx);
        seg = seg - mean(seg,2,'omitnan');
        seg = seg .* taper;
        X = fft(seg,nfft,2);
        P = abs(X(:,1:(nfft/2+1))).^2 ./ winSamp;
        for b = 1:nBand
            fidx = freq >= bands(b).Range(1) & freq < bands(b).Range(2);
            val = mean(P(:,fidx),2,'omitnan');
            if useLogPower; val = log10(val+eps); end
            bp(w,:,b) = val;
        end
    end
end

function z = zscore_safe_row(x)
    x = x(:)'; mu = mean(x,'omitnan'); sd = std(x,0,'omitnan');
    if isnan(sd) || sd==0; z = zeros(size(x)); z(isnan(x)) = NaN; else; z = (x-mu)./sd; end
end

function rows = compute_windowed_isc_mean(Pz, subIDs, condName, bands, winSec, stepSec, powerStepSec)
    [nSub,nTime,nChan,nBand] = size(Pz);
    winPts = round(winSec/powerStepSec);
    stepPts = round(stepSec/powerStepSec);
    starts = 1:stepPts:(nTime-winPts+1);
    if isempty(starts); error('Time series too short for %d-s window.', winSec); end
    rowsCell = cell(nSub*nBand, 5); rr = 0;
    for b = 1:nBand
        zSubjChan = nan(nSub,nChan);
        for ch = 1:nChan
            X = squeeze(Pz(:,:,ch,b)); % sub x time
            zSubj = nan(nSub,1);
            for s = 1:nSub
                ref = mean(X(setdiff(1:nSub,s),:),1,'omitnan');
                zWin = nan(numel(starts),1);
                for w = 1:numel(starts)
                    idx = starts(w):(starts(w)+winPts-1);
                    r = corr(X(s,idx)', ref(idx)', 'Rows','complete');
                    zWin(w) = fisher_z(r);
                end
                zSubj(s) = mean(zWin,'omitnan');
            end
            zSubjChan(:,ch) = zSubj;
        end
        whole = mean(zSubjChan,2,'omitnan');
        for s = 1:nSub
            rr = rr + 1;
            rowsCell(rr,:) = {subIDs(s), condName, string(bands(b).Name), whole(s), numel(starts)};
        end
    end
    rows = cell2table(rowsCell, 'VariableNames', {'Subject_ID','Condition','Band','ISC_meanZ','nCorrWindows'});
end

function z = fisher_z(r)
    if isnan(r); z = NaN; return; end
    r = max(min(r,0.999999),-0.999999); z = atanh(r);
end

function [friedT, posthocT] = run_window_condition_stats(T, bands, winList)
    condOrder = ["Rest","Fear","Neutral"];
    friedRows = {}; postRows = {};
    for wi = 1:numel(winList)
        winSec = winList(wi);
        for b = 1:numel(bands)
            bandName = string(bands(b).Name);
            subList = unique(T.Subject_ID);
            X = nan(numel(subList), numel(condOrder));
            for s = 1:numel(subList)
                for c = 1:numel(condOrder)
                    idx = T.WinSec==winSec & T.Subject_ID==subList(s) & string(T.Condition)==condOrder(c) & string(T.Band)==bandName;
                    if any(idx); X(s,c)=T.ISC_meanZ(find(idx,1)); end
                end
            end
            Xv = X(all(isfinite(X),2),:);
            [pF,tbl] = friedman(Xv,1,'off');
            friedRows(end+1,:) = {winSec, bandName, size(Xv,1), tbl{2,5}, tbl{2,3}, pF}; %#ok<AGROW>
            pairs = [1 2; 1 3; 2 3]; pairNames = ["Rest_vs_Fear","Rest_vs_Neutral","Fear_vs_Neutral"];
            pRaw = nan(3,1); meanDiff = nan(3,1);
            for k = 1:3
                try; pRaw(k)=signrank(Xv(:,pairs(k,1)), Xv(:,pairs(k,2))); catch; pRaw(k)=NaN; end
                meanDiff(k)=mean(Xv(:,pairs(k,2))-Xv(:,pairs(k,1)),'omitnan');
            end
            pHolm = holm_adjust(pRaw);
            for k = 1:3
                postRows(end+1,:) = {winSec, bandName, pairNames(k), meanDiff(k), pRaw(k), pHolm(k)}; %#ok<AGROW>
            end
        end
    end
    friedT = cell2table(friedRows, 'VariableNames', {'WinSec','Band','N','ChiSquare','df','p_raw'});
    friedT.p_FDR_BH = bh_fdr(friedT.p_raw);
    posthocT = cell2table(postRows, 'VariableNames', {'WinSec','Band','Contrast','MeanDiff_SecondMinusFirst','p_raw','p_Holm'});
end

function pAdj = holm_adjust(p)
    pAdj = nan(size(p)); ok = isfinite(p); pv = p(ok); [ps,order]=sort(pv); m=numel(ps); adj=nan(size(ps));
    for i=1:m; adj(i)=(m-i+1)*ps(i); end
    for i=2:m; adj(i)=max(adj(i),adj(i-1)); end
    adj=min(adj,1); tmp=nan(size(pv)); tmp(order)=adj; pAdj(ok)=tmp;
end

function q = bh_fdr(p)
    p=p(:); q=nan(size(p)); ok=isfinite(p); pv=p(ok); if isempty(pv); return; end
    [ps,order]=sort(pv); m=numel(ps); qs=ps.*m./(1:m)'; qs=flipud(cummin(flipud(qs))); qs(qs>1)=1; tmp=nan(size(pv)); tmp(order)=qs; q(ok)=tmp;
end
